package com.example.mwsfinalproject.Package_Burger

data class BurgerModel(

    val ID: String?,
    val Nama_Burger: String?,
    val Harga: String?,
    val Deskripsi: String?,
)
