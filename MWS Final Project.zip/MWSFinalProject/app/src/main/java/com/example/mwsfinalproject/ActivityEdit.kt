package com.example.mwsfinalproject

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class ActivityEdit : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.layout_edit)
    }
}