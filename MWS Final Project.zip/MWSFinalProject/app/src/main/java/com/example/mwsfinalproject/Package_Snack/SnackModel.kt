package com.example.restapiui

data class SnackModel(

    val ID: String?,
    val Nama_Snack: String?,
    val Harga: String?,
    val Deskripsi: String?,
)