package com.example.mwsfinalproject.Package_Pizza

data class PizzaModel(

    val ID: String?,
    val Nama_Pizza: String?,
    val Harga: String?,
    val Deskripsi: String?,
)
